Python 3.11.3 (tags/v3.11.3:f3909b8, Apr  4 2023, 23:49:59) [MSC v.1934 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> for i1 in range(5, 0, -1):
...     for i2 in range(5-i1):
...         print(' ', end='')
...         for i3 in range(i1):
...             print('*', end='')
... 
...             
 **** *** *** ** ** ** * * * *
>>>     print()
...     
SyntaxError: unexpected indent
>>> for i1 in range(5, 0, -1):
...     for i2 in range(5-i1):
...         print(' ', end='')
...     for i3 in range(i1):
...         print('*', end='')
...     print()
... 
...     
*****
 ****
  ***
   **
    *
